<?php 

$firstName = $_POST['firstName'];
$lastName = $_POST['lastName'];
$mobile = $_POST['mobile'];
$email = $_POST['email'];
$specialist = $_POST['doctor'];
$date = $_POST['date'];
$time = $_POST['time'];
$age = $_POST['age'];
$comment = $_POST['desc'];

$conn = new mysqli('localhost','root','','smile');
if($conn->connect_error){
		die('Connection Failed : '.$conn->connect_error);
}else{

$stmnt = $conn->prepare("insert into consult(email,firstName,lastName,mobile,doctor,date,time,age,description) values(?,?,?,?,?,?,?,?,?)");
$stmnt->bind_param("sssisssis",$email,$firstName,$lastName,$mobile,$specialist,$date,$time,$age,$comment);
$stmnt->execute();
echo "data entered successfully";
$stmnt->close();
$conn->close();

}
?>