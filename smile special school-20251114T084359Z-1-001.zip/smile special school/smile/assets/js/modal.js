

function modalQ1() {
    var count_p1 = 0;
    var count_p2 = 0;
    if (document.getElementById('opt1-1').checked) {
        count_p1 += 1;
    } else if (document.getElementById('opt1-2').checked) {
        count_p2 += 1;
    }
    if (document.getElementById('opt2-1').checked) {
        count_p1 += 1;
    } else if (document.getElementById('opt2-2').checked) {
        count_p2 += 1;
    }
    if (document.getElementById('opt3-1').checked) {
        count_p1 += 1;
    }
     else if (document.getElementById('opt3-2').checked) {
        count_p2 += 1;
    }
    if (document.getElementById('opt4-1').checked) {
        count_p1 += 1;
    } else if (document.getElementById('opt4-2').checked) {
        count_p2 += 1;
    }
    if (document.getElementById('opt5-1').checked) {
        count_p1 += 1;
    } else if (document.getElementById('opt5-2').checked) {
        count_p2 += 1;
    }
    if (document.getElementById('opt6-1').checked) {
        count_p1 += 1;
    } else if (document.getElementById('opt6-2').checked) {
        count_p2 += 1;
    }
    if (document.getElementById('opt7-1').checked) {
        count_p1 += 1;
    } else if (document.getElementById('opt7-2').checked) {
        count_p2 += 1;
    }
    if (count_p1 == 7) {
        document.getElementById('p1').checked = true;
        document.getElementById('f1').checked = false;
    }
    if (count_p2 == 7) {
        document.getElementById('f1').checked = true;
        document.getElementById('p1').checked = false;
    }
    if (count_p1 > count_p2) {
        document.getElementById('p1').checked = true;
        document.getElementById('f1').checked = false;
    } else {
        document.getElementById('f1').checked = true;
        document.getElementById('p1').checked = false;
    }
}

function modalQ2() {
    var count_opt1 = 0;
    var count_opt2 = 0;
    if (document.getElementById('opt2-1-1').checked) {
        count_opt1 += 1;
    } else if (document.getElementById('opt2-1-2').checked) {
        count_opt2 += 1;
    }
    if (document.getElementById('opt2-2-1').checked) {
        count_opt1 += 1;
    } else if (document.getElementById('opt2-2-2').checked) {
        count_opt2 += 1;
    }
    if (count_opt2 == 2) {
        document.getElementById('p2').checked = true;
        document.getElementById('f2').checked = false;
    }
    if (count_opt1==1) {
        document.getElementById('f2').checked = true;
        document.getElementById('p2').checked = false;
    } 
}


function modalQ3() {
    var count_opt1 = 0;
    var count_opt2 = 0;
    if (document.getElementById('opt3-1-1').checked) {
        count_opt1 += 1;
    } else if (document.getElementById('opt3-1-2').checked) {
        count_opt2 += 1;
    }
    if (document.getElementById('opt3-2-1').checked) {
        count_opt1 += 1;
    } else if (document.getElementById('opt3-2-2').checked) {
        count_opt2 += 1;
    }
    if (document.getElementById('opt3-3-1').checked) {
        count_opt1 += 1;
    } else if (document.getElementById('opt3-3-2').checked) {
        count_opt2 += 1;
    }
    if (document.getElementById('opt3-4-1').checked) {
        count_opt1 += 1;
    } else if (document.getElementById('opt3-4-2').checked) {
        count_opt2 += 1;
    }
    if (document.getElementById('opt3-5-1').checked) {
        count_opt1 += 1;
    } else if (document.getElementById('opt3-5-2').checked) {
        count_opt2 += 1;
    }
    if (document.getElementById('opt3-6-1').checked) {
        count_opt1 += 1;
    } else if (document.getElementById('opt3-6-2').checked) {
        count_opt2 += 1;
    }
    if (document.getElementById('opt3-7-1').checked) {
        count_opt1 += 1;
    } else if (document.getElementById('opt3-7-2').checked) {
        count_opt2 += 1;
    }
    if (document.getElementById('opt3-8-1').checked) {
        count_opt1 += 1;
    } else if (document.getElementById('opt3-8-2').checked) {
        count_opt2 += 1;
    }
    if (document.getElementById('opt3-9-1').checked) {
        count_opt1 += 1;
    } else if (document.getElementById('opt3-9-2').checked) {
        count_opt2 += 1;
    }
    if (document.getElementById('opt3-10-1').checked) {
        count_opt1 += 1;
    } else if (document.getElementById('opt3-10-2').checked) {
        count_opt2 += 1;
    }
    if (document.getElementById('opt3-11-1').checked) {
        count_opt1 += 1;
    } else if (document.getElementById('opt3-11-2').checked) {
        count_opt2 += 1;
    }
    if (count_opt2 == 11) {
        document.getElementById('f3').checked = true;
        document.getElementById('p3').checked = false;
    }
    if (count_opt1>=1) {
        document.getElementById('p3').checked = true;
        document.getElementById('f3').checked = false;
    } 
}


function modalQ4() {
    var count_opt1 = 0;
    var count_opt2 = 0;
    if (document.getElementById('opt4-1-1').checked) {
        count_opt1 += 1;
    } else if (document.getElementById('opt4-1-2').checked) {
        count_opt2 += 1;
    }
    if (document.getElementById('opt4-2-1').checked) {
        count_opt1 += 1;
    } else if (document.getElementById('opt4-2-2').checked) {
        count_opt2 += 1;
    }
    if (document.getElementById('opt4-3-1').checked) {
        count_opt1 += 1;
    } else if (document.getElementById('opt4-3-2').checked) {
        count_opt2 += 1;
    }
    if (document.getElementById('opt4-4-1').checked) {
        count_opt1 += 1;
    } else if (document.getElementById('opt4-4-2').checked) {
        count_opt2 += 1;
    }
    if (count_opt1>=1) {
        document.getElementById('p4').checked = true;
        document.getElementById('f4').checked = false;
    } 
    if (count_opt2 == 4) {
        document.getElementById('f4').checked = true;
        document.getElementById('p4').checked = false;
    }
}


function modalQ5() {
    var count_opt1 = 0;
    var count_opt2 = 0;
    var count_opt11=0;
    var count_opt22=0;
    if (document.getElementById('opt5-1-1').checked) {
        count_opt1 += 1;
    } else if (document.getElementById('opt5-1-2').checked) {
        count_opt2 += 1;
    }
    if (document.getElementById('opt5-2-1').checked) {
        count_opt1 += 1;
    } else if (document.getElementById('opt5-2-2').checked) {
        count_opt2 += 1;
    }
    if (document.getElementById('opt5-3-1').checked) {
        count_opt11 += 1;
    } else if (document.getElementById('opt5-3-2').checked) {
        count_opt22 += 1;
    }
    if (document.getElementById('opt5-4-1').checked) {
        count_opt11 += 1;
    } else if (document.getElementById('opt5-4-2').checked) {
        count_opt22 += 1;
    }
    if (document.getElementById('opt5-5-1').checked) {
        count_opt11 += 1;
    } else if (document.getElementById('opt5-5-2').checked) {
        count_opt22 += 1;
    }
    if (document.getElementById('opt5-6-1').checked) {
        count_opt11 += 1;
    } else if (document.getElementById('opt5-6-2').checked) {
        count_opt22 += 1;
    }
    if (document.getElementById('opt5-1-1').checked || document.getElementById('opt5-1-2').checked || count_opt22==0 || document.getElementById('opt5-7-2').checked) {
        document.getElementById('p5').checked = true;
        document.getElementById('f5').checked = false;
    } 
    if (count_opt11>=1) {
        if(document.getElementById('opt5-7-1').checked){
        document.getElementById('f5').checked = true;
        document.getElementById('p5').checked = false;
        }
    }
}

function modalQ6() {
    var count_opt1 = 0;
    var count_opt2 = 0;
    if (document.getElementById('opt6-1-1').checked) {
        count_opt1 += 1;
    } else if (document.getElementById('opt6-1-2').checked) {
        count_opt2 += 1;
    }
    if (document.getElementById('opt6-2-1').checked) {
        count_opt1 += 1;
    } else if (document.getElementById('opt6-2-2').checked) {
        count_opt2 += 1;
    }
    if (document.getElementById('opt6-3-1').checked) {
        count_opt1 += 1;
    } else if (document.getElementById('opt6-3-2').checked) {
        count_opt2 += 1;
    }
    if (document.getElementById('opt6-4-1').checked) {
        count_opt1 += 1;
    } else if (document.getElementById('opt6-4-2').checked) {
        count_opt2 += 1;
    } 
    if (count_opt2==4 && document.getElementById('opt6-5-2').checked) {
        document.getElementById('f6').checked = true;
        document.getElementById('p6').checked = false;
    }
    if (count_opt1>=1 && document.getElementById('opt6-5-1').checked) {
        document.getElementById('p6').checked = true;
        document.getElementById('f6').checked = false;
    }
}

function modalQ7(){
    var count_opt1 = 0;
    var count_opt2 = 0;
    if (document.getElementById('opt7-1-1').checked) {
        count_opt1 += 1;
    } else if (document.getElementById('opt7-1-2').checked) {
        count_opt2 += 1;
    }
    if (document.getElementById('opt7-2-1').checked) {
        count_opt1 += 1;
    } else if (document.getElementById('opt7-2-2').checked) {
        count_opt2 += 1;
    }
    if (document.getElementById('opt7-3-1').checked) {
        count_opt1 += 1;
    } else if (document.getElementById('opt7-3-2').checked) {
        count_opt2 += 1;
    }
    if (document.getElementById('opt7-4-1').checked) {
        count_opt1 += 1;
    } else if (document.getElementById('opt7-4-2').checked) {
        count_opt2 += 1;
    } 
    if (document.getElementById('opt7-5-1').checked) {
        //count_opt1 += 1;
    } else if (document.getElementById('opt7-5-2').checked) {
        count_opt2 += 1;
    } 
    if (document.getElementById('opt7-6-1').checked) {
        //count_opt1 += 1;
    } else if (document.getElementById('opt7-6-2').checked) {
        count_opt2 += 1;
    } 
    if (count_opt2==6) {
        document.getElementById('f7').checked = true;
        document.getElementById('p7').checked = false;
    }
    if (count_opt1>=1 && document.getElementById('opt7-5-1').checked && document.getElementById('opt7-6-1').checked ) {
        document.getElementById('p7').checked = true;
        document.getElementById('f7').checked = false;
    }
}

function modalQ8(){
    var count_opt1 = 0;
    var count_opt2 = 0;
    if (document.getElementById('opt8-3-1').checked) {
        count_opt1 += 1;
    } else if (document.getElementById('opt8-3-2').checked) {
        count_opt2 += 1;
    }
    if (document.getElementById('opt8-4-1').checked) {
        count_opt1 += 1;
    } else if (document.getElementById('opt8-4-2').checked) {
        count_opt2 += 1;
    } 
    if (document.getElementById('opt8-5-1').checked) {
        count_opt1 += 1;
    } else if (document.getElementById('opt8-5-2').checked) {
        count_opt2 += 1;
    } 
    if (document.getElementById('opt8-6-1').checked) {
        count_opt1 += 1;
    } else if (document.getElementById('opt8-6-2').checked) {
        count_opt2 += 1;
    } 
    if (document.getElementById('opt8-7-1').checked) {
        count_opt1 += 1;
    } else if (document.getElementById('opt8-7-2').checked) {
        count_opt2 += 1;
    } 
    if (document.getElementById('opt8-8-1').checked) {
        count_opt1 += 1;
    } else if (document.getElementById('opt8-8-2').checked) {
        count_opt2 += 1;
    } 
    if (document.getElementById('opt8-9-1').checked) {
        count_opt1 += 1;
    } else if (document.getElementById('opt8-9-2').checked) {
        count_opt2 += 1;
    }  
    if (count_opt2==7 && document.getElementById('opt8-2-2').checked && document.getElementById('opt8-10-2').checked) {
        document.getElementById('f8').checked = true;
        document.getElementById('p8').checked = false;
    }
    if (document.getElementById('opt8-1-1').checked && document.getElementById('opt8-2-1').checked && count_opt1>=1 && document.getElementById('opt8-10-1').checked  ) {
        document.getElementById('p8').checked = true;
        document.getElementById('f8').checked = false;
    }
}

function modalQ9()
{
    var count_opt111 = 0;
    var count_opt222 = 0;
    if (document.getElementById('opt9-1-1').checked) {
        count_opt111 += 1;
    } else if (document.getElementById('opt9-1-2').checked) {
        count_opt222 += 1;
    }
    if (document.getElementById('opt9-2-1').checked) {
        count_opt111 += 1;
    } else if (document.getElementById('opt9-2-2').checked) {
        count_opt222 += 1;
    }
    if (document.getElementById('opt9-3-1').checked) {
        count_opt111 += 1;
    } else if (document.getElementById('opt9-3-2').checked) {
        count_opt222 += 1;
    }
    if (document.getElementById('opt9-4-1').checked) {
        count_opt111 += 1;
    } else if (document.getElementById('opt9-4-2').checked) {
        count_opt222 += 1;
    } 
    if (document.getElementById('opt9-5-1').checked) {
        count_opt111 += 1;
    } else if (document.getElementById('opt9-5-2').checked) {
        count_opt222 += 1;
    } 
    if(count_opt222==5 || document.getElementById('opt9-6-2').checked )
    {
        document.getElementById('f9').checked = true;
        document.getElementById('p9').checked = false;
    }
    if(count_opt111>=1 && document.getElementById('opt9-6-1').checked)
    {
        document.getElementById('p9').checked = true;
        document.getElementById('f9').checked = false;
    }
}


function modalQ10()
{
    var count_opt1 = 0;
    var count_opt2 = 0;
    var count_opt11=0;
    var count_opt22=0;
    if (document.getElementById('opt10-1-1').checked) {
        count_opt1 += 1;
    } else if (document.getElementById('opt10-1-2').checked) {
        count_opt2 += 1;
    }
    if (document.getElementById('opt10-2-1').checked) {
        count_opt1 += 1;
    } else if (document.getElementById('opt10-2-2').checked) {
        count_opt2 += 1;
    }
    if (document.getElementById('opt10-3-1').checked) {
        count_opt1 += 1;
    } else if (document.getElementById('opt10-3-2').checked) {
        count_opt2 += 1;
    }
    if (document.getElementById('opt10-4-1').checked) {
        count_opt11 += 1;
    } else if (document.getElementById('opt10-4-2').checked) {
        count_opt22 += 1;
    } 
    if (document.getElementById('opt10-5-1').checked) {
        count_opt11 += 1;
    } else if (document.getElementById('opt10-5-2').checked) {
        count_opt22 += 1;
    } 
    if (document.getElementById('opt10-6-1').checked) {
        count_opt11 += 1;
    } else if (document.getElementById('opt10-6-2').checked) {
        count_opt22 += 1;
    } 
    if (document.getElementById('opt10-7-1').checked) {
        count_opt11 += 1;
    } else if (document.getElementById('opt10-7-2').checked) {
        count_opt22 += 1;
    } 
    if (count_opt1==3 || document.getElementById('opt10-8-1').checked ) {
        document.getElementById('p10').checked = true;
        document.getElementById('f10').checked = false;
    }
    if(count_opt22==4 || document.getElementById('opt10-8-2').checked){
        document.getElementById('f10').checked = true;
        document.getElementById('p10').checked = false;
    }
    if (count_opt1>=1 && count_opt11>=1 && count_opt22>=1 && document.getElementById('opt10-8-2').checked) {
        document.getElementById('f10').checked = true;
        document.getElementById('p10').checked = false;
    }
}


function modalQ11()
{
    var count_opt1 = 0;
    var count_opt2 = 0;
    var count_opt11=0;
    var count_opt22=0;
    if (document.getElementById('opt11-1-1').checked) {
        count_opt1 += 1;
    } else if (document.getElementById('opt11-1-2').checked) {
        count_opt2 += 1;
    }
    if (document.getElementById('opt11-2-1').checked) {
        count_opt1 += 1;
    } else if (document.getElementById('opt11-2-2').checked) {
        count_opt2 += 1;
    }
    if (document.getElementById('opt11-3-1').checked) {
        count_opt1 += 1;
    } else if (document.getElementById('opt11-3-2').checked) {
        count_opt2 += 1;
    }
    if (document.getElementById('opt11-4-1').checked) {
        count_opt11 += 1;
    } else if (document.getElementById('opt11-4-2').checked) {
        count_opt22 += 1;
    } 
    if (document.getElementById('opt11-5-1').checked) {
        count_opt11 += 1;
    } else if (document.getElementById('opt11-5-2').checked) {
        count_opt22 += 1;
    } 
    if (document.getElementById('opt11-6-1').checked) {
        count_opt11 += 1;
    } else if (document.getElementById('opt11-6-2').checked) {
        count_opt22 += 1;
    } 
    if (count_opt1==3 || document.getElementById('opt11-7-1').checked ) {
        document.getElementById('p11').checked = true;
        document.getElementById('f11').checked = false;
    }
    if(count_opt11==3 || document.getElementById('opt11-7-2').checked){
        document.getElementById('f11').checked = true;
        document.getElementById('p11').checked = false;
    }
}


function modalQ12()
{
    var t1_opt1 = 0;
    var t1_opt2 = 0;
    var t2_opt1 = 0;
    var t2_opt2 = 0;
    var t3_opt1 = 0;
    var t3_opt2 = 0;
    if (document.getElementById('opt12-1-1').checked) {
        t1_opt1 += 1;
    } else if (document.getElementById('opt12-1-2').checked) {
        t1_opt2 += 1;
    }
    if (document.getElementById('opt12-2-1').checked) {
        t1_opt1 += 1;
    } else if (document.getElementById('opt12-2-2').checked) {
        t2_opt2 += 1;
    }
    if (document.getElementById('opt12-3-1').checked) {
        t1_opt1 += 1;
    } else if (document.getElementById('opt12-3-2').checked) {
        t2_opt1 += 1;
    }
    if (document.getElementById('opt12-4-1').checked) {
        t1_opt1 += 1;
    } else if (document.getElementById('opt12-4-2').checked) {
        t2_opt1 += 1;
    } 
    if (document.getElementById('opt12-5-1').checked) {
        t1_opt1 += 1;
    } else if (document.getElementById('opt12-5-2').checked) {
        t2_opt1 += 1;
    } 
    if (document.getElementById('opt12-6-1').checked) {
        t1_opt1 += 1;
    } else if (document.getElementById('opt12-6-2').checked) {
        t2_opt1 += 1;
    } 
    if (document.getElementById('opt12-7-1').checked) {
        t1_opt1 += 1;
    } else if (document.getElementById('opt12-7-2').checked) {
        t2_opt1 += 1;
    } 
    if (document.getElementById('opt12-8-1').checked) {
        t1_opt1 += 1;
    } else if (document.getElementById('opt12-8-2').checked) {
        t2_opt1 += 1;
    } 
    if (document.getElementById('opt12-9-1').checked) {
        t1_opt1 += 1;
    } else if (document.getElementById('opt12-9-2').checked) {
        t2_opt1 += 1;
    } 
    if (document.getElementById('opt12-10-1').checked) {
        t2_opt1 += 1;
    } else if (document.getElementById('opt12-10-2').checked) {
        t2_opt2 += 1;
    } 
    if (document.getElementById('opt12-11-1').checked) {
        t2_opt1 += 1;
    } else if (document.getElementById('opt12-11-2').checked) {
        t2_opt2 += 1;
    } 
    if (document.getElementById('opt12-12-1').checked) {
        t3_opt1 += 1;
    } else if (document.getElementById('opt12-12-2').checked) {
        t3_opt2 += 1;
    } 
    if (document.getElementById('opt12-13-1').checked) {
        t3_opt1 += 1;
    } else if (document.getElementById('opt12-13-2').checked) {
        t3_opt2 += 1;
    } 
    if (document.getElementById('opt12-14-1').checked) {
        t3_opt1 += 1;
    } else if (document.getElementById('opt12-14-2').checked) {
        t3_opt2 += 1;
    } 
    if (t1_opt1>=2 && t2_opt1==2 || document.getElementById('opt12-15-1').checked) {
        document.getElementById('p12').checked = true;
        document.getElementById('f12').checked = false;
        document.getElementById('opt12-12-1').disabled = true;
        document.getElementById('opt12-13-1').disabled = true;
        document.getElementById('opt12-14-1').disabled = true;
        document.getElementById('opt12-12-2').disabled = true;
        document.getElementById('opt12-13-2').disabled = true;
        document.getElementById('opt12-14-2').disabled = true;
        document.getElementById('opt12-10-1').disabled = false;
        document.getElementById('opt12-10-2').disabled = false;
        document.getElementById('opt12-11-1').disabled = false;
        document.getElementById('opt12-11-2').disabled = false;
    }
    if(t1_opt1>=2 && t3_opt1==2 || document.getElementById('opt12-15-2').checked){
        document.getElementById('f12').checked = true;
        document.getElementById('p12').checked = false;
        document.getElementById('opt12-10-1').disabled = true;
        document.getElementById('opt12-10-2').disabled = true;
        document.getElementById('opt12-11-1').disabled = true;
        document.getElementById('opt12-11-2').disabled = true;
        document.getElementById('opt12-12-1').disabled = false;
        document.getElementById('opt12-13-1').disabled = false;
        document.getElementById('opt12-14-1').disabled = false;
        document.getElementById('opt12-12-2').disabled = false;
        document.getElementById('opt12-13-2').disabled = false;
        document.getElementById('opt12-14-2').disabled = false;
    }
}

function modalQ13()
{
    if (document.getElementById('opt13-1-1').checked) {
        document.getElementById('p13').checked = true;
        document.getElementById('f13').checked = false; 
    } else if (document.getElementById('opt13-1-2').checked) {
        document.getElementById('f13').checked = true;
        document.getElementById('p13').checked = false;
    }
}


function modalQ14()
{
    var count_opt111 = 0;
    var count_opt222 = 0;
    if (document.getElementById('opt14-2-1').checked) {
        count_opt111 += 1;
    } else if (document.getElementById('opt14-2-2').checked) {
        count_opt222 += 1;
    }
    if (document.getElementById('opt14-3-1').checked) {
        count_opt111 += 1;
    } else if (document.getElementById('opt14-3-2').checked) {
        count_opt222 += 1;
    }
    if (document.getElementById('opt14-4-1').checked) {
        count_opt111 += 1;
    } else if (document.getElementById('opt14-4-2').checked) {
        count_opt222 += 1;
    } 
    if (document.getElementById('opt14-5-1').checked) {
        count_opt111 += 1;
    } else if (document.getElementById('opt14-5-2').checked) {
        count_opt222 += 1;
    } 
    if (document.getElementById('opt14-6-1').checked) {
        count_opt111 += 1;
    } else if (document.getElementById('opt14-6-2').checked) {
        count_opt222 += 1;
    } 
    if (document.getElementById('opt14-7-1').checked) {
        count_opt111 += 1;
    } else if (document.getElementById('opt14-7-2').checked) {
        count_opt222 += 1;
    } 
    if (document.getElementById('opt14-1-1').checked ||  count_opt111>=2 && document.getElementById('opt14-8-1').checked && document.getElementById('opt14-9-1').checked) {
        document.getElementById('p14').checked = true;
        document.getElementById('f14').checked = false;
    } 
    if (document.getElementById('opt14-1-2').checked && count_opt222==6 && document.getElementById('opt14-8-2').checked && document.getElementById('opt14-9-2').checked) {
        document.getElementById('f14').checked = true;
        document.getElementById('p14').checked = false;
    }
    if (document.getElementById('opt14-1-2').checked && count_opt111==1 && document.getElementById('opt14-8-1').checked && document.getElementById('opt14-9-2').checked) {
        document.getElementById('f14').checked = true;
        document.getElementById('p14').checked = false;
    }
    if (document.getElementById('opt14-1-2').checked && count_opt111==1 && document.getElementById('opt14-8-1').checked && document.getElementById('opt14-9-1').checked) {
        document.getElementById('p14').checked = true;
        document.getElementById('f14').checked = false;
    }
}

function modalQ15()
{
    var count_opt111 = 0;
    var count_opt222 = 0;
    if (document.getElementById('opt15-1-1').checked) {
        count_opt111 += 1;
    } else if (document.getElementById('opt15-1-2').checked) {
        count_opt222 += 1;
    }
    if (document.getElementById('opt15-2-1').checked) {
        count_opt111 += 1;
    } else if (document.getElementById('opt15-2-2').checked) {
        count_opt222 += 1;
    }
    if (document.getElementById('opt15-3-1').checked) {
        count_opt111 += 1;
    } else if (document.getElementById('opt15-3-2').checked) {
        count_opt222 += 1;
    }
    if (document.getElementById('opt15-4-1').checked) {
        count_opt111 += 1;
    } else if (document.getElementById('opt15-4-2').checked) {
        count_opt222 += 1;
    } 
    if (document.getElementById('opt15-5-1').checked) {
        count_opt111 += 1;
    } else if (document.getElementById('opt15-5-2').checked) {
        count_opt222 += 1;
    } 
    if (document.getElementById('opt15-6-1').checked) {
        count_opt111 += 1;
    } else if (document.getElementById('opt15-6-2').checked) {
        count_opt222 += 1;
    } 
    
    if ( count_opt111>=2) {
        document.getElementById('p15').checked = true;
        document.getElementById('f15').checked = false;
    } 
    if ( count_opt111<=1) {
        document.getElementById('f15').checked = true;
        document.getElementById('p15').checked = false;
    } 
}

function modalQ16()
{
    var count_opt1 = 0;
    var count_opt2 = 0;
    var count_opt111 = 0;
    var count_opt222 = 0;
    if (document.getElementById('opt16-1-1').checked) {
        count_opt1 += 1;
    } else if (document.getElementById('opt16-1-2').checked) {
        count_opt2 += 1;
    }
    if (document.getElementById('opt16-2-1').checked) {
        count_opt1 += 1;
    } else if (document.getElementById('opt16-2-2').checked) {
        count_opt2 += 1;
    }
    if (document.getElementById('opt16-3-1').checked) {
        count_opt1 += 1;
    } else if (document.getElementById('opt16-3-2').checked) {
        count_opt2 += 1;
    }
    if (document.getElementById('opt16-4-1').checked) {
        count_opt111 += 1;
    } else if (document.getElementById('opt16-4-2').checked) {
        count_opt222 += 1;
    } 
    if (document.getElementById('opt16-5-1').checked) {
        count_opt111 += 1;
    } else if (document.getElementById('opt16-5-2').checked) {
        count_opt222 += 1;
    }  
    
    if ( count_opt1==3 || document.getElementById('opt16-6-1').checked) {
        document.getElementById('p16').checked = true;
        document.getElementById('f16').checked = false;
        document.getElementById('opt16-4-1').disabled = true;
        document.getElementById('opt16-4-2').disabled = true;
        document.getElementById('opt16-5-1').disabled = true;
        document.getElementById('opt16-5-2').disabled = true;
    } 
    if (count_opt2==2 || document.getElementById('opt16-6-2').checked ) {
        document.getElementById('f16').checked = true;
        document.getElementById('p16').checked = false;
        document.getElementById('opt16-1-1').disabled = true;
        document.getElementById('opt16-1-2').disabled = true;
        document.getElementById('opt16-2-1').disabled = true;
        document.getElementById('opt16-2-2').disabled = true;
        document.getElementById('opt16-3-1').disabled = true;
        document.getElementById('opt16-3-2').disabled = true;
    }
    if (count_opt1>=1 && count_opt2>=1 && document.getElementById('opt16-6-1').checked ) {
        document.getElementById('p16').checked = true;
        document.getElementById('f16').checked = false;
    }
    if (count_opt1>=1 && count_opt2>=1 && document.getElementById('opt16-6-2').checked ) {
        document.getElementById('f16').checked = true;
        document.getElementById('p16').checked = false;
    }
}

function modalQ17()
{
    var count_opt111 = 0;
    var count_opt222 = 0;
    if (document.getElementById('opt17-1-1').checked) {
        count_opt111 += 1;
    } else if (document.getElementById('opt17-1-2').checked) {
        count_opt222 += 1;
    }
    if (document.getElementById('opt17-2-1').checked) {
        count_opt111 += 1;
    } else if (document.getElementById('opt17-2-2').checked) {
        count_opt222 += 1;
    }
    if (document.getElementById('opt17-3-1').checked) {
        count_opt111 += 1;
    } else if (document.getElementById('opt17-3-2').checked) {
        count_opt222 += 1;
    }
    if (document.getElementById('opt17-4-1').checked) {
        count_opt111 += 1;
    } else if (document.getElementById('opt17-4-2').checked) {
        count_opt222 += 1;
    } 
    
    
    if ( count_opt111>=1) {
        document.getElementById('p17').checked = true;
        document.getElementById('f17').checked = false;
    } 
    if ( count_opt222==4) {
        document.getElementById('f17').checked = true;
        document.getElementById('p17').checked = false;
    } 
}

function modalQ18()
{
    var count_opt111 = 0;
    var count_opt222 = 0;
    if (document.getElementById('opt18-3-1').checked) {
        count_opt111 += 1;
    } else if (document.getElementById('opt17-3-2').checked) {
        count_opt222 += 1;
    }
    if (document.getElementById('opt18-4-1').checked) {
        count_opt111 += 1;
    } else if (document.getElementById('opt18-4-2').checked) {
        count_opt222 += 1;
    }
    if (document.getElementById('opt18-5-1').checked) {
        count_opt111 += 1;
    } else if (document.getElementById('opt18-5-2').checked) {
        count_opt222 += 1;
    }
    
    
    if ((document.getElementById('opt18-1-1').checked || document.getElementById('opt18-2-1').checked) && count_opt111>=1) {
        document.getElementById('p18').checked = true;
        document.getElementById('f18').checked = false;
    } 
    if ( (document.getElementById('opt18-1-2').checked && document.getElementById('opt18-2-2').checked) || count_opt222==0) {
        document.getElementById('f18').checked = true;
        document.getElementById('p18').checked = false;
    } 
}

function modalQ19()
{
    if ((document.getElementById('opt19-1-1').checked && document.getElementById('opt19-2-1').checked) || document.getElementById('opt19-3-1').checked) {
        document.getElementById('p19').checked = true;
        document.getElementById('f19').checked = false;
    } 
    if ( document.getElementById('opt19-1-2').checked && document.getElementById('opt19-2-2').checked || document.getElementById('opt19-3-2').checked) {
        document.getElementById('f19').checked = true;
        document.getElementById('p19').checked = false;
    } 
}


function modalQ20()
{
    var count_opt111 = 0;
    var count_opt222 = 0;
    if (document.getElementById('opt20-2-1').checked) {
        count_opt111 += 1;
    } else if (document.getElementById('opt20-2-2').checked) {
        count_opt222 += 1;
    }
    if (document.getElementById('opt20-3-1').checked) {
        count_opt111 += 1;
    } else if (document.getElementById('opt20-3-2').checked) {
        count_opt222 += 1;
    }
    if (document.getElementById('opt20-4-1').checked) {
        count_opt111 += 1;
    } else if (document.getElementById('opt20-4-2').checked) {
        count_opt222 += 1;
    }
    
    
    if (document.getElementById('opt20-1-1').checked || count_opt111>=1) {
        document.getElementById('p20').checked = true;
        document.getElementById('f20').checked = false;
    } 

    if ( document.getElementById('opt20-1-2').checked && count_opt222==3 ) {
        document.getElementById('f20').checked = true;
        document.getElementById('p20').checked = false;
    } 
}