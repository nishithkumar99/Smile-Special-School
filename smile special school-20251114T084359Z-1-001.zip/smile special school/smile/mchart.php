<?php 

$mobile =$_POST['mobile'];

$q1 = $_POST['yesno1'];

$q2 = $_POST['yesno2'];

$q3 = $_POST['yesno3'];

$q4 = $_POST['yesno4'];

$q5 = $_POST['yesno5'];

$q6 = $_POST['yesno6'];

$q7 = $_POST['yesno7'];

$q8 = $_POST['yesno8'];

$q9 = $_POST['yesno9'];

$q10 = $_POST['yesno10'];

$q11 = $_POST['yesno11'];

$q12 = $_POST['yesno12'];

$q13 = $_POST['yesno13'];

$q14 = $_POST['yesno14'];

$q15 = $_POST['yesno15'];

$q16 = $_POST['yesno16'];

$q17 = $_POST['yesno17'];

$q18 = $_POST['yesno18'];

$q19 = $_POST['yesno19'];

$q20 = $_POST['yesno20'];

$conn = new mysqli('localhost','root','','smile');
if($conn->connect_error){
		die('Connection Failed : '.$conn->connect_error);
}else{

$stmnt = $conn->prepare("insert into mchart(mobile,q1,q2,q3,q4,q5,q6,q7,q8,q9,q10,q11,q12,q13,q14,q15,q16,q17,q18,q19,q20) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
$stmnt->bind_param("issssssssssssssssssss",$mobile,$q1,$q2,$q3,$q4,$q5,$q6,$q7,$q8,$q9,$q10,$q11,$q12,$q13,$q14,$q15,$q16,$q17,$q18,$q19,$q20);
$stmnt->execute();
echo "data entered successfully";
$stmnt->close();
$conn->close();

}
?>