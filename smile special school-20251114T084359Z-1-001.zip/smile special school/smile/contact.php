<?php 

$name = $_POST['name'];

$em = $_POST['email'];

$msg = $_POST['message'];


$conn = new mysqli('localhost','root','','smile');
if($conn->connect_error){
		die('Connection Failed : '.$conn->connect_error);
}else{

$stmnt = $conn->prepare("insert into getintouch(email,name,message) values(?,?,?)");
$stmnt->bind_param("sss",$em,$name,$msg);
$stmnt->execute();
echo "data entered successfully";
$stmnt->close();
$conn->close();

}
?>