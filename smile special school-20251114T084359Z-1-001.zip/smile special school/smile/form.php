<?php 

$firstName = $_POST['firstName'];
$lastName = $_POST['lastName'];
$mobile = $_POST['mobile'];
$age = $_POST['age'];
$gender = $_POST['gender'];
$education = $_POST['education'];
$fatherName = $_POST['fatherName'];
$address = $_POST['address'];
$complaint = $_POST['complaint'];
$suggestion=$_POST['suggestion'];


$age_at_conception=$_POST['age_at_conception'];
$age_yesno=$_POST['age_yesno'];
$ranc=$_POST['ranc'];
$ranc_yesno=$_POST['ranc_yesno'];
$abortion=$_POST['abortion_yesno'];
$foetel_movement=$_POST['foetel_movement'];
$foetel_yesno=$_POST['foetel_yesno'];
$nutri_status=$_POST['nutri_status'];
$nutri_yesno=$_POST['nutri_yesno'];
$health=$_POST['health'];
$health_yesno=$_POST['health_yesno'];


$gestation_period=$_POST['gestation_period'];
$gastation_yesno=$_POST['gastation_yesno'];
$del_place=$_POST['del_place'];
$del_place_yesno=$_POST['del_place_yesno'];
$birth_cry=$_POST['birth_cry'];
$birth_cry_yesno=$_POST['birth_cry_yesno'];
$birth_weight=$_POST['birth_weight'];
$birth_weight_yesno=$_POST['birth_weight_yesno'];
$birth_color=$_POST['birth_color'];
$birth_color_yesno=$_POST['birth_color_yesno'];
$other=$_POST['other'];




$nutri_status=$_POST['nutri_status'];
$nutri_status_yesno=$_POST['nutri_status_yesno'];
$feeding_problem=$_POST['feeding_problem'];
$feeding_problem_yesno=$_POST['feeding_problem_yesno'];
$incubation=$_POST['incubation'];
$incubation_yesno=$_POST['incubation_yesno'];
$any_events=$_POST['any_events'];
$events_yesno=$_POST['events_yesno'];
$congenital=$_POST['congenital'];
$immunization=$_POST['immunization'];
$immunization_yesno=$_POST['immunization_yesno'];








$marriage=$_POST['marriage'];
$marital_status=$_POST['marital_status'];
$family_type=$_POST['family_type'];
$family_status=$_POST['family_status'];
$no_of_family=$_POST['no_of_familymembers'];
$socio_economic_status=$_POST['Socio_economic_status'];
$residence_type=$_POST['residence_type'];
$rural_urban=$_POST['rural_urban'];
$parent_child_interaction=$_POST['parent_child_interaction'];
$fam_history=$_POST['fam_history'];


$age=$_POST['age'];
$school_type=$_POST['school_type'];
$present_standard=$_POST['present_standard'];
$school_performance=$_POST['school_performance'];
$eca=$_POST['eca'];
$interaction=$_POST['interaction'];
$discrepant_subject=$_POST['discrepant_subject'];
$problem=$_POST['problem'];


$plays_with=$_POST['plays_with'];
$play_behavior=$_POST['play_behavior'];
$plays_game=$_POST['plays_game'];

$help=$_POST['help'];
$work_setting=$_POST['work_setting'];
$working_style=$_POST['working_style'];
$work_nature=$_POST['work_nature'];


$neigh_part=$_POST['neigh_part'];
$visiting=$_POST['visiting'];
$participation=$_POST['participation'];
$support=$_POST['support'];


$conn = new mysqli('localhost','root','','smile');
if($conn->connect_error){
		die('Connection Failed : '.$conn->connect_error);
}else{

$stmnt = $conn->prepare("insert into personal_info(mobile,firstName,lastName,age,Gender,Education,Father_Name,Address,Complaint,suggestions) values(?,?,?,?,?,?,?,?,?,?)");
$stmnt->bind_param("ississssss",$mobile,$firstName,$lastName,$age,$gender,$education,$fatherName,$address,$complaint,$suggestion);


$stmnt1_1 = $conn->prepare("insert into personal_history_parental(mobile,mother_age,mother_age_yesno,ranc,ranc_yesno,Abortions,Abortion_yesno,Foetel_movement,Foetel_movement_yesno,mother_nutrition,mother_nutrition_yesno,mothers_health,mothers_health_yesno) values(?,?,?,?,?,?,?,?,?,?,?,?,?)");
$stmnt1_1->bind_param("iisssssssssss",$mobile,$age_at_conception,$age_yesno,$ranc,$ranc_yesno,$abortion,$foetel_movement,$foetel_yesno,$nutri_status,$nutri_yesno,$health,$health_yesno);


$stmnt1_2 = $conn->prepare("insert into personal_history_natal(mobile,gestation_period,gestation_period_yesno,delivery_place,delivery_place_yesno,birth_cry,birth_cry_yesno,birth_weight,birth_weight_yesno,birth_color,birth_color_yesno,other) values(?,?,?,?,?,?,?,?,?,?,?,?)");
$stmnt1_2->bind_param("isssssssssss",$mobile,$gestation_period,$gastation_yesno,$del_place,$del_place_yesno,$birth_cry,$birth_cry_yesno,$birth_weight,$birth_weight_yesno,$birth_color,$birth_color_yesno,$birth_color_yesno,$other);

$stmnt1_3 = $conn->prepare("insert into personal_history_postnatal(mobile,Nutritional_status,Nutritional_status_yesno,feeding_problem,feeding_problem_yesno,incubation,incubation_yesno,other_events,other_events_yesno,Congenital_Deformitie,immunization,immunization_yesno) values(?,?,?,?,?,?,?,?,?,?,?,?)");
$stmnt1_3->bind_param("isssssssssss",$mobile,Nutritional_status,Nutritional_status_yesno,feeding_problem,feeding_problem_yesno,incubation,incubation_yesno,other_events,other_events_yesno,Congenital_Deformitie,immunization,immunization_yesno);


$stmnt2 = $conn->prepare("insert into family_info(Marriage,Martial_Status,Type_of_family,Status_of_family,No_of_family_members,Socio_economic_status,Residence_type,Residence_area,Parent_child_intreaction,family_history) values(?,?,?,?,?,?,?,?,?,?,?)");
$stmnt2->bind_param("issssisssss",$mobile,$marriage,$marital_status,$family_type,$family_status,$no_of_family,$socio_economic_status,$residence_type,$rural_urban,$parent_child_interaction,$fam_history);

$stmnt3 = $conn->prepare("insert into school_history(mobile,Age_at_admission,Type_of_school,Present_Standard,School_Performance,ExtraCircular_Activities,Interaction,Discrepant_in_subjects,Problem_in_school) values(?,?,?,?,?,?,?,?,?)");
$stmnt3->bind_param("iisssssss",$mobile,$age,$school_type,$present_standard,$school_performance,$eca,$interaction,$discrepant_subject,$problem);

$stmnt4=$conn->prepare("insert into play_history(mobile,Play_with,Behaviour,games) values(?,?,?,?)");
$stmnt4->bind_param("isss",$mobile,$plays_with,$play_behavior,$plays_game);


$stmnt5=$conn->prepare("insert into occupational_history(mobile,how_helps,Work_setting,Working_Style,Nature_of_work) values(?,?,?,?,?)");
$stmnt5->bind_param("issss",$mobile,$help,$work_setting,$working_style,$work_nature);


$stmnt6=$conn->prepare("insert into social_involvment(mobile,interaction,visiting_family,participation,support) values(?,?,?,?,?)");
$stmnt6->bind_param("issss",$mobile,$neigh_part,$visiting,$participation,$support);

$stmnt->execute();
$stmnt1_1->execute();
$stmnt1_2->execute();
$stmnt1_3->execute();
$stmnt2->execute();
$stmnt3->execute();
$stmnt4->execute();
$stmnt5->execute();
$stmnt6->execute();

echo "data entered successfully";
$stmnt->close();
$stmnt1_1->close();
$stmnt1_2->close();
$stmnt1_3->close();
$stmnt2->close();
$stmnt3->close();
$stmnt4->close();
$stmnt5->close();
$stmnt6->close();
$conn->close();

}
?>